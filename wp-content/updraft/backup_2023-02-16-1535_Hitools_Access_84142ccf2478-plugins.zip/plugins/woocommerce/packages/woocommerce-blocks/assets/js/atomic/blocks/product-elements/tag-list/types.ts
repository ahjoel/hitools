export interface BlocksAttributes {
	productId: number;
}
