export interface Attributes {
	productId: number;
	isDescendentOfQueryLoop: boolean;
}
