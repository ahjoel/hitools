export interface BlockAttributes {
	productId: number;
	isDescendentOfQueryLoop: boolean;
}
